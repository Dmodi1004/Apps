package com.example.bottomnavigaionbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.bottomnavigaionbar.Fragments.HomeFragment;
import com.example.bottomnavigaionbar.Fragments.LikeFragment;
import com.example.bottomnavigaionbar.Fragments.ProfileFragment;
import com.example.bottomnavigaionbar.Fragments.SearchFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigationView = findViewById(R.id.bottomNavigation);

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fram, new HomeFragment());
        transaction.commit();

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

                switch (item.getItemId()) {

                    case R.id.home:
                        transaction.replace(R.id.fram, new HomeFragment());
                        break;
                    case R.id.like:
                        transaction.replace(R.id.fram, new LikeFragment());
                        break;
                    case R.id.search:
                        transaction.replace(R.id.fram, new SearchFragment());
                        break;
                    case R.id.user:
                        transaction.replace(R.id.fram, new ProfileFragment());
                        break;

                }
                transaction.commit();
                return true;
            }
        });

    }
}