package com.example.bottomnavigaionbar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.example.bottomnavigaionbar.Fragments.HomeFragment;
import com.example.bottomnavigaionbar.Fragments.LikeFragment;
import com.example.bottomnavigaionbar.Fragments.ProfileFragment;
import com.example.bottomnavigaionbar.Fragments.SearchFragment;
import com.volcaniccoder.bottomify.BottomifyNavigationView;
import com.volcaniccoder.bottomify.OnNavigationItemChangeListener;
//import com.iammert.library.readablebottombar.ReadableBottomBar;

//import nl.joery.animatedbottombar.AnimatedBottomBar;

public class ReadebleBottomActivity extends AppCompatActivity {

    BottomifyNavigationView readableBottomBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_readeble_bottom);

        readableBottomBar = findViewById(R.id.readableBottomBar);

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.containers, new HomeFragment());
        transaction.commit();

        readableBottomBar.setOnNavigationItemChangedListener(new OnNavigationItemChangeListener() {
            @Override
            public void onNavigationItemChanged(BottomifyNavigationView.NavigationItem navigationItem) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

                switch (navigationItem.getPosition()) {

                    case 0:
                        transaction.replace(R.id.containers, new HomeFragment());
                        break;
                    case 1:
                        transaction.replace(R.id.containers, new LikeFragment());
                        break;
                    case 2:
                        transaction.replace(R.id.containers, new SearchFragment());
                        break;
                    case 3:
                        transaction.replace(R.id.containers, new ProfileFragment());
                        break;

                }
                transaction.commit();
            }
        });


    }
}