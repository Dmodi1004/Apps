package com.example.wallpapers;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AbsListView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.wallpapers.adapters.SuggestedAdapter;
import com.example.wallpapers.adapters.WallpaperAdapter;
import com.example.wallpapers.databinding.ActivityMainBinding;
import com.example.wallpapers.interfaces.RecyclerViewClickListener;
import com.example.wallpapers.models.SuggestedModel;
import com.example.wallpapers.models.WallpaperModel;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, RecyclerViewClickListener {

    ActivityMainBinding binding;

    FirebaseAuth auth;

    static final float END_SCALE = 0.7f;

    private long backPressed;
    private Toast backToast;

    Boolean isScrolling = false;
    int currentItems, totalItems, scrollOutItems;

    int pageNumber = 1;
    String url = "https://api.pexels.com/v1/curated?page=" + pageNumber + "&per_page=80"; //We need multiple pages when scrolled.

    RecyclerView.Adapter adapter;
    WallpaperAdapter wallpaperAdapter;
    List<WallpaperModel> wallpaperModelList;

    ArrayList<SuggestedModel> suggestedModels = new ArrayList<>();

    TextView replaceTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setTheme(R.style.Theme_Wallpapers);
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        auth = FirebaseAuth.getInstance();

        navigationDrawer();

        //Navigation drawer profile
        View headerView = binding.navigationView.getHeaderView(0);
        ImageView appLogo = headerView.findViewById(R.id.app_image);

        wallpaperModelList = new ArrayList<>();
        wallpaperAdapter = new WallpaperAdapter(this, wallpaperModelList);

        binding.recyclerView.setAdapter(wallpaperAdapter);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        binding.recyclerView.setLayoutManager(gridLayoutManager);

        //Scrolling behaviour
        binding.recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                if (newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) {
                    isScrolling = true;
                }
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                currentItems = gridLayoutManager.getChildCount();
                totalItems = gridLayoutManager.getItemCount();
                scrollOutItems = gridLayoutManager.findFirstVisibleItemPosition();

                if (isScrolling && (currentItems + scrollOutItems == totalItems)) {
                    isScrolling = false;
                    fetchWallpaper();
                }
            }
        });

        binding.progressBar.setVisibility(View.VISIBLE);

        replaceTitle = (TextView) findViewById(R.id.topMostTitle);

        fetchWallpaper();

        suggestedItems();

        //Search edit text and imageView

        binding.searchEdt.setOnKeyListener((view, i, keyEvent) -> {

            if (keyEvent.getAction() == KeyEvent.ACTION_DOWN)
            {
                switch (i)
                {
                    case KeyEvent.KEYCODE_DPAD_CENTER:
                    case KeyEvent.KEYCODE_ENTER:

                        String searchEdt = binding.searchEdt.getText().toString();

                        if (!searchEdt.isEmpty()){
                            replaceTitle.setText(searchEdt);
                            url = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query="+searchEdt;
                            wallpaperModelList.clear();
                            fetchWallpaper();

                            binding.searchEdt.requestFocus();
                            binding.progressBar.setVisibility(View.GONE);
                        }

                        return true;
                    default:
                        break;
                }
            }

            return false;
        });

        binding.searchImage.setOnClickListener(view -> {
            //Set the functionality later

            String searchEdt = binding.searchEdt.getText().toString();

            if (!searchEdt.isEmpty()){
                replaceTitle.setText(searchEdt);
                url = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query="+searchEdt;
                wallpaperModelList.clear();
                fetchWallpaper();
                binding.progressBar.setVisibility(View.GONE);
            }

        });

    }

    private void navigationDrawer() {
        //Navigation Drawer
        binding.navigationView.bringToFront();
        binding.navigationView.setNavigationItemSelectedListener(this);
        binding.navigationView.setCheckedItem(R.id.nav_home);

        binding.menuIcon.setOnClickListener(view -> {
            if (binding.drawerLayout.isDrawerVisible(GravityCompat.START)) {
                binding.drawerLayout.closeDrawer(GravityCompat.START);
            } else {
                binding.drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        //Animation in the drawer
        animationNavigationDrawer();

    }

    private void animationNavigationDrawer() {
        binding.drawerLayout.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {
                //Scale the view based on the current slide offset
                final float diffScaledOffset = slideOffset * (1 - END_SCALE);
                final float offsetScale = 1 - diffScaledOffset;
                binding.contentView.setScaleX(offsetScale);
                binding.contentView.setScaleY(offsetScale);

                //Translate the view accounting of the scaled width
                final float xOffset = binding.drawerLayout.getWidth() * slideOffset;
                final float xOffsetDiff = binding.contentView.getWidth() * diffScaledOffset / 2;
                final float xTranslation = xOffset - xOffsetDiff;
                binding.contentView.setTranslationX(xTranslation);
            }

            @Override
            public void onDrawerOpened(@NonNull View drawerView) {

            }

            @Override
            public void onDrawerClosed(@NonNull View drawerView) {

            }

            @Override
            public void onDrawerStateChanged(int newState) {

            }
        });
    }

    @Override
    public void onBackPressed() {

        if (binding.drawerLayout.isDrawerVisible(GravityCompat.START)) {
            binding.drawerLayout.closeDrawer(GravityCompat.START);
        } else if (backPressed + 3000 > System.currentTimeMillis()) {
            super.onBackPressed();
            backToast.cancel();
            return;
        } else {
            backToast = Toast.makeText(this, "Press back again to Exit", Toast.LENGTH_LONG);
            backToast.show();
        }
        backPressed = System.currentTimeMillis();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (auth.getCurrentUser() == null) {
            openLogin();
        }
    }

    private void openLogin() {
        startActivity(new Intent(this, LoginActivity.class));
        finishAffinity();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.nav_home:
                binding.drawerLayout.closeDrawer(GravityCompat.START);
//                Toast.makeText(this, "Home Clicked", Toast.LENGTH_SHORT).show();
                break;
            case R.id.nav_trending:

                binding.drawerLayout.closeDrawer(GravityCompat.START);

                replaceTitle.setText("Trending");
                url = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=trending";
                wallpaperModelList.clear();
                fetchWallpaper();
//                Toast.makeText(this, "Trending Clicked", Toast.LENGTH_SHORT).show();
                break;
            case R.id.nav_most_viewed:

                binding.drawerLayout.closeDrawer(GravityCompat.START);

                replaceTitle.setText("New");
                url = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=new";
                wallpaperModelList.clear();
                fetchWallpaper();

//                Toast.makeText(this, "Most Viewed Clicked", Toast.LENGTH_SHORT).show();
                break;
            case R.id.nav_logout:

                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(this, LoginActivity.class));
                finishAffinity();
                Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
                break;
            case R.id.nav_about:
                Toast.makeText(this, "About Clicked", Toast.LENGTH_SHORT).show();
                break;

        }

        return true;
    }

    private void suggestedItems() {
        binding.suggestedRecyclerView.setHasFixedSize(true);
        binding.suggestedRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        suggestedModels.add(new SuggestedModel(R.drawable.wallhaven, "Trending"));
        suggestedModels.add(new SuggestedModel(R.drawable.wallpaperflare, "Nature"));
        suggestedModels.add(new SuggestedModel(R.drawable.day_to_night, "Architecture"));
        suggestedModels.add(new SuggestedModel(R.drawable.wallhaven, "People"));
        suggestedModels.add(new SuggestedModel(R.drawable.wallpaperflare, "Business"));
        suggestedModels.add(new SuggestedModel(R.drawable.day_to_night, "Health"));
        suggestedModels.add(new SuggestedModel(R.drawable.wallhaven, "Fashion"));
        suggestedModels.add(new SuggestedModel(R.drawable.wallpaperflare, "Travel"));
        suggestedModels.add(new SuggestedModel(R.drawable.day_to_night, "Film"));

        adapter = new SuggestedAdapter(suggestedModels, this);
        binding.suggestedRecyclerView.setAdapter(adapter);

    }

    private void fetchWallpaper() {

        //Fetch image url and name from the pexels api.

        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                binding.progressBar.setVisibility(View.GONE);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("photos");

                    int length = jsonArray.length();

                    for (int i = 0; i < length; i++) {
                        JSONObject object = jsonArray.getJSONObject(i);
                        int id = object.getInt("id");
                        String photographerName = object.getString("photographer");

                        JSONObject objectImage = object.getJSONObject("src");
                        String originalUrl = objectImage.getString("original");
                        String mediumUrl = objectImage.getString("medium");

                        WallpaperModel wallpaperModel = new WallpaperModel(id, originalUrl, mediumUrl, photographerName);
                        wallpaperModelList.add(wallpaperModel);
                    }

                    wallpaperAdapter.notifyDataSetChanged();
                    pageNumber++;

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("Authorization", "563492ad6f9170000100000117616df1d42d463da39fd9b2499cc66e");
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(request);

    }

    @Override
    public void onItemClick(int position) {
        binding.progressBar.setVisibility(View.VISIBLE);

        if (position == 0) {
            replaceTitle.setText("Trending");
            url = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=trending";
            wallpaperModelList.clear();
            fetchWallpaper();
            binding.progressBar.setVisibility(View.GONE);
        } else if (position == 1) {
            replaceTitle.setText("Nature");
            url = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=nature";
            wallpaperModelList.clear();
            fetchWallpaper();
            binding.progressBar.setVisibility(View.GONE);
        } else if (position == 2) {
            replaceTitle.setText("Architecture");
            url = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=architecture";
            wallpaperModelList.clear();
            fetchWallpaper();
            binding.progressBar.setVisibility(View.GONE);
        } else if (position == 3) {
            replaceTitle.setText("People");
            url = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=people";
            wallpaperModelList.clear();
            fetchWallpaper();
            binding.progressBar.setVisibility(View.GONE);
        } else if (position == 4) {
            replaceTitle.setText("Business");
            url = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=business";
            wallpaperModelList.clear();
            fetchWallpaper();
            binding.progressBar.setVisibility(View.GONE);
        } else if (position == 5) {
            replaceTitle.setText("Health");
            url = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=health";
            wallpaperModelList.clear();
            fetchWallpaper();
            binding.progressBar.setVisibility(View.GONE);
        } else if (position == 6) {
            replaceTitle.setText("Fashion");
            url = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=fashion";
            wallpaperModelList.clear();
            fetchWallpaper();
            binding.progressBar.setVisibility(View.GONE);
        } else if (position == 7) {
            replaceTitle.setText("Travel");
            url = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=travel";
            wallpaperModelList.clear();
            fetchWallpaper();
            binding.progressBar.setVisibility(View.GONE);
        } else if (position == 8) {
            replaceTitle.setText("Film");
            url = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=film";
            wallpaperModelList.clear();
            fetchWallpaper();
            binding.progressBar.setVisibility(View.GONE);
        }

    }
}