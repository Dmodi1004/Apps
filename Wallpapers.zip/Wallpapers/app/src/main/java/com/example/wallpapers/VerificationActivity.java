package com.example.wallpapers;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.example.wallpapers.databinding.ActivityVerificationBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class VerificationActivity extends AppCompatActivity {

    ActivityVerificationBinding binding;

    private String id, number;
    private FirebaseAuth auth;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityVerificationBinding.inflate(getLayoutInflater());
        setTheme(R.style.Theme_Wallpapers);
        setContentView(binding.getRoot());

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        auth = FirebaseAuth.getInstance();

        number = getIntent().getStringExtra("number");

        sendVerificationCode();

        binding.submit.setOnClickListener(view -> {
            if (binding.edtOtp.getText().toString().isEmpty()) {
                binding.edtOtp.setError("Enter the OTP");
                binding.edtOtp.requestFocus();
            } else {
                binding.loader.setVisibility(View.VISIBLE);

                PhoneAuthCredential credential = PhoneAuthProvider.getCredential(id, binding.edtOtp.getText().toString().replace(" ", ""));
                signInWithPhoneAuthCredential(credential);
            }
        });

        binding.resend.setOnClickListener(view -> {
            sendVerificationCode();
        });

    }

    private void sendVerificationCode() {

        new CountDownTimer(60000, 100) {

            @Override
            public void onTick(long l) {
                binding.resend.setText("" + l/1000);
                binding.resend.setEnabled(false);
            }

            @Override
            public void onFinish() {
                binding.resend.setText(" Resend");
                binding.resend.setEnabled(true);
            }
        }.start();

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(auth)
                        .setPhoneNumber(number)       // Phone number to verify
                        .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                        .setActivity(this)                 // Activity (for callback binding)
                        .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

                            @Override
                            public void onVerificationCompleted(PhoneAuthCredential credential) {

                                signInWithPhoneAuthCredential(credential);
                            }

                            @Override
                            public void onVerificationFailed(FirebaseException e) {
                                Toast.makeText(VerificationActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            @Override
                            public void onCodeSent(@NonNull String id,
                                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {
                                VerificationActivity.this.id = id;
                            }
                        })
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);

    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {

        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        binding.loader.setVisibility(View.GONE);

                        if (task.isSuccessful()) {

                            startActivity(new Intent(VerificationActivity.this, MainActivity.class));
                            finish();

                            FirebaseUser user = task.getResult().getUser();
                        } else {
                            Toast.makeText(VerificationActivity.this, "Verification failed please try again " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });

    }
}