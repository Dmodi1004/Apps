package com.example.wallpapers.interfaces;

public interface RecyclerViewClickListener {
    void onItemClick(int position);
}
