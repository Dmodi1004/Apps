package com.example.wallpapers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Toast;

import com.example.wallpapers.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {

    ActivityLoginBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setTheme(R.style.Theme_Wallpapers);
        setContentView(binding.getRoot());

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        binding.ccp.registerCarrierNumberEditText(binding.edtNumber);

        binding.next.setOnClickListener(view -> {
            if (binding.edtNumber.toString().isEmpty()) {
                binding.edtNumber.setError("Enter your number");
                binding.edtNumber.requestFocus();
            } else if (binding.edtNumber.getText().toString().trim().replace(" ", "").length() != 10){
                Toast.makeText(this, "Please enter a valid Phone Number", Toast.LENGTH_SHORT).show();
            }else {
                Intent intent = new Intent(this, VerificationActivity.class);
                intent.putExtra("number", binding.ccp.getFullNumberWithPlus().replace(" ", ""));
                startActivity(intent);
            }
        });

    }
}