package com.example.wallpapers;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.app.WallpaperManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.artjimlop.altex.AltexImageDownloader;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.example.wallpapers.databinding.ActivityFullScreenWallpaperBinding;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.io.IOException;
import java.util.List;

public class FullScreenWallpaper extends AppCompatActivity {

    ActivityFullScreenWallpaperBinding binding;

    String originalUrl = "";

    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFullScreenWallpaperBinding.inflate(getLayoutInflater());
        setTheme(R.style.Theme_Wallpapers);
        setContentView(binding.getRoot());

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Wait a second...");
        progressDialog.setCancelable(false);

        Intent intent = getIntent();
        originalUrl = intent.getStringExtra("originalUrl");

        Glide.with(this).load(originalUrl)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        binding.progressBar.setVisibility(View.GONE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        binding.progressBar.setVisibility(View.GONE);
                        return false;
                    }
                })
                .into(binding.photoView);

        binding.setWallpaper.setOnClickListener(view -> {
            progressDialog.show();
            @SuppressLint("StaticFieldLeak") AsyncTask<String, String, String> demoSetWallpaper = new AsyncTask<String, String, String>() {
                @Override
                protected String doInBackground(String... strings) {

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    return "demo";
                }

                @Override
                protected void onPostExecute(String s) {
                    if (s.equals("demo")) {
                        WallpaperManager wallpaperManager = WallpaperManager.getInstance(FullScreenWallpaper.this);
                        Bitmap bitmap = ((BitmapDrawable) binding.photoView.getDrawable()).getBitmap();

                        try {
                            wallpaperManager.setBitmap(bitmap);
                            Toast.makeText(FullScreenWallpaper.this, "Wallpaper Set", Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                }
            };
            demoSetWallpaper.execute();
        });
        binding.downloadWallpaper.setOnClickListener(view -> {
            progressDialog.show();

            checkPermission();

        });

    }

    private void checkPermission() {

        Dexter.withContext(this)
                .withPermissions(
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE
                ).withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {

                        if (report.areAllPermissionsGranted()) {

                            progressDialog.show();
                            @SuppressLint("StaticFieldLeak") AsyncTask<String, String, String> demoSetWallpaper = new AsyncTask<String, String, String>() {
                                @Override
                                protected String doInBackground(String... strings) {

                                    try {
                                        Thread.sleep(1000);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }

                                    return "demo";
                                }

                                @Override
                                protected void onPostExecute(String s) {
                                    if (s.equals("demo")) {
                                        AltexImageDownloader.writeToDisk(FullScreenWallpaper.this, originalUrl, "wallpapers");
                                        Toast.makeText(FullScreenWallpaper.this, "Downloading..!!", Toast.LENGTH_SHORT).show();
                                        progressDialog.dismiss();
                                    }
                                }
                            };
                            demoSetWallpaper.execute();

                        } else {
                            Toast.makeText(FullScreenWallpaper.this, "Please allow all permission.", Toast.LENGTH_SHORT).show();
                        }

                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {

                    }

                }).check();

    }


}