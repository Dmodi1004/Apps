package com.example.admincollegeapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.admincollegeapp.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {

    ActivityLoginBinding binding;
    private String email, password;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.Theme_AdminCollegeApp);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getSupportActionBar().hide();

        sharedPreferences = this.getSharedPreferences("login", MODE_PRIVATE);
        editor = sharedPreferences.edit();

        if (sharedPreferences.getString("isLogin", "false").equals("yesregi")){
            openDash();
        }

        binding.txtShow.setOnClickListener(view -> {

            if (binding.userPassword.getText().toString().isEmpty()) {

            } else {
                if (binding.userPassword.getInputType() == 144) {
                    binding.userPassword.setInputType(129);
                    binding.txtShow.setText("HIDE");
                } else {
                    binding.userPassword.setInputType(144);
                    binding.txtShow.setText("SHOW");
                }
                binding.userPassword.setSelection(binding.userPassword.getText().length());
            }
        });

        binding.loginBtn.setOnClickListener(view -> {
            validateData();
        });

    }

    private void validateData() {
        email = binding.userEmail.getText().toString();
        password = binding.userPassword.getText().toString();

        if (email.isEmpty()) {
            binding.userEmail.setError("Enter your email");
            binding.userEmail.requestFocus();
        } else if (password.isEmpty()) {
            binding.userPassword.setError("Enter your password");
            binding.userPassword.requestFocus();
        } else if (email.equals("admin@gmail.com") && password.equals("123456")){
            editor.putString("isLogin", "yes");
            editor.commit();
            openDash();
        } else {
            Toast.makeText(this, "Please check your Email and Password again.", Toast.LENGTH_LONG).show();
        }

    }

    private void openDash() {
        startActivity(new Intent(LoginActivity.this, MainActivity.class));
        finishAffinity();
    }
}