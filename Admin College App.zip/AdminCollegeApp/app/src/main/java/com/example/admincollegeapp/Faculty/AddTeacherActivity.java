package com.example.admincollegeapp.Faculty;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.admincollegeapp.Models.TeacherData;
import com.example.admincollegeapp.R;
import com.example.admincollegeapp.databinding.ActivityAddTeacherBinding;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class AddTeacherActivity extends AppCompatActivity {

    ActivityAddTeacherBinding binding;

    private final int REQ = 1;
    private Bitmap bitmap = null;
    private String category;
    private String name, email, post, downloadUrl = "";

    FirebaseDatabase database;
    FirebaseStorage storage;
    StorageReference storageReference;
    DatabaseReference reference, dbRef;

    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddTeacherBinding.inflate(getLayoutInflater());
        setTheme(R.style.Theme_AdminCollegeApp);
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);

        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();
        reference = database.getReference().child("teacher");
        storageReference = storage.getReference();

        binding.teacherBtn.setOnClickListener(view -> {
            checkValidation();
        });

        binding.teacherImg.setOnClickListener(view -> {
            openGallery();
        });

        String[] items = new String[]{"Select Category", "Computer Science", "Mechanical", "Physics", "Chemistry"};
        binding.teacherCategory.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items));

        binding.teacherCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                category = binding.teacherCategory.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    private void checkValidation() {

        name = binding.teacherName.getText().toString();
        email = binding.teacherEmail.getText().toString();
        post = binding.teacherPost.getText().toString();

        if (name.isEmpty()) {
            binding.teacherName.setError("Name");
            binding.teacherName.requestFocus();
        } else if (email.isEmpty()) {
            binding.teacherEmail.setError("Email");
            binding.teacherEmail.requestFocus();
        } else if (post.isEmpty()) {
            binding.teacherPost.setError("Post");
            binding.teacherPost.requestFocus();
        } else if (category.equals("Select Category")) {
            Toast.makeText(this, "Select Teacher Category", Toast.LENGTH_SHORT).show();
        } else if (bitmap == null) {
            progressDialog.setMessage("Uploading...");
            progressDialog.show();
            insertData();
        } else {
            progressDialog.setMessage("Uploading...");
            progressDialog.show();
            insertImage();
        }

    }

    private void insertImage() {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);
        byte[] finalimg = baos.toByteArray();
        final StorageReference filepath;
        filepath = storageReference.child("teachers").child(finalimg + "jpg");
        final UploadTask uploadTask = filepath.putBytes(finalimg);
        uploadTask.addOnCompleteListener(this, task -> {

            if (task.isSuccessful()) {

                uploadTask.addOnSuccessListener(taskSnapshot -> {

                    filepath.getDownloadUrl().addOnSuccessListener(uri -> {

                        downloadUrl = String.valueOf(uri);
                        insertData();
                    });
                });
            } else {
                progressDialog.dismiss();
                Toast.makeText(this, task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void insertData() {

        dbRef = reference.child(category);
        final String uniqueKey = dbRef.push().getKey();

        TeacherData teacherData = new TeacherData(name, email, post, downloadUrl, uniqueKey);

        dbRef.child(uniqueKey).setValue(teacherData)
                .addOnSuccessListener(runnable -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Teacher Added", Toast.LENGTH_SHORT).show();
                }).addOnFailureListener(e -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                });

    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQ);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ && resultCode == RESULT_OK) {
            Uri uri = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            binding.teacherImg.setImageBitmap(bitmap);
        }

    }

}