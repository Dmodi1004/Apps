package com.example.admincollegeapp.Notice;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.admincollegeapp.Models.NoticeData;
import com.example.admincollegeapp.R;
import com.example.admincollegeapp.databinding.ActivityUploadNoticeBinding;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class UploadNoticeActivity extends AppCompatActivity {

    ActivityUploadNoticeBinding binding;

    FirebaseDatabase database;
    DatabaseReference reference, dbRef;
    FirebaseStorage storage;
    StorageReference storageReference;

    String downloadUrl = "";

    private ProgressDialog progressDialog;
    private final int REQ = 10;
    private Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUploadNoticeBinding.inflate(getLayoutInflater());
        setTheme(R.style.Theme_AdminCollegeApp);
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);

        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();
        reference = database.getReference();
        storageReference = storage.getReference();

        binding.addImage.setOnClickListener(view -> {
            openGallery();
        });

        binding.uploadNoticeBtn.setOnClickListener(view -> {
            if (binding.noticeTitle.getText().toString().isEmpty()) {
                binding.noticeTitle.setError("Enter the title");
                binding.noticeTitle.requestFocus();
            } else if (bitmap == null) {
                uploadData();
            } else {
                uploadImage();
            }
        });

    }

    private void uploadImage() {

        progressDialog.setMessage("Uploading...");
        progressDialog.show();

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);
        byte[] finalimg = baos.toByteArray();
        final StorageReference filepath;
        filepath = storageReference.child("notice").child(finalimg + "jpg");
        final UploadTask uploadTask = filepath.putBytes(finalimg);
        uploadTask.addOnCompleteListener(UploadNoticeActivity.this, task -> {

            if (task.isSuccessful()) {

                uploadTask.addOnSuccessListener(taskSnapshot -> {

                    filepath.getDownloadUrl().addOnSuccessListener(uri -> {

                        downloadUrl = String.valueOf(uri);
                        uploadData();
                    });
                });
            } else {
                progressDialog.dismiss();
                Toast.makeText(this, task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void uploadData() {
        dbRef = reference.child("notice");
        final String uniqueKey = dbRef.push().getKey();

        String title = binding.noticeTitle.getText().toString();

        Calendar calDate = Calendar.getInstance();
        SimpleDateFormat currentDate = new SimpleDateFormat("dd-MM-yy");
        String date = currentDate.format(calDate.getTime());

        Calendar calTime = Calendar.getInstance();
        SimpleDateFormat currentTime = new SimpleDateFormat("hh:mm a");
        String time = currentTime.format(calTime.getTime());

        NoticeData noticeData = new NoticeData(title, downloadUrl, date, time, uniqueKey);

        dbRef.child(uniqueKey).setValue(noticeData)
                .addOnSuccessListener(runnable -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Notice Uploaded", Toast.LENGTH_SHORT).show();
                }).addOnFailureListener(e -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                });


    }

    private void openGallery() {

        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQ);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ && resultCode == RESULT_OK) {
            Uri uri = data.getData();
            binding.cardImg.setVisibility(View.VISIBLE);
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            binding.noticeImage.setImageBitmap(bitmap);
        }

    }
}