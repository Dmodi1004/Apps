package com.example.admincollegeapp.Faculty;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.admincollegeapp.R;
import com.example.admincollegeapp.databinding.ActivityUpdateTeacherBinding;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;

public class UpdateTeacherActivity extends AppCompatActivity {

    ActivityUpdateTeacherBinding binding;

    private StorageReference storageReference;
    private DatabaseReference reference;

    String name, email, image, post;
    private final int REQ = 1;
    private Bitmap bitmap = null;
    private String downloadUrl, category, uniqueKey;

    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUpdateTeacherBinding.inflate(getLayoutInflater());
        setTheme(R.style.Theme_AdminCollegeApp);
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        pd = new ProgressDialog(this);
        pd.setCancelable(false);

        reference = FirebaseDatabase.getInstance().getReference("teacher");
        storageReference = FirebaseStorage.getInstance().getReference();

        name = getIntent().getStringExtra("name");
        email = getIntent().getStringExtra("email");
        post = getIntent().getStringExtra("post");
        image = getIntent().getStringExtra("image");

        uniqueKey = getIntent().getStringExtra("key");
        category = getIntent().getStringExtra("category");

        try {
            Picasso.get().load(image).placeholder(R.drawable.avatar).into(binding.updateTeacherImg);
        } catch (Exception e) {
            e.printStackTrace();
        }

        binding.updateTeacherName.setText(name);
        binding.updateTeacherEmail.setText(email);
        binding.updateTeacherPost.setText(post);

        binding.updateTeacherImg.setOnClickListener(view -> {
            openGallery();
        });

        binding.updateBtn.setOnClickListener(view -> {

            name = binding.updateTeacherName.getText().toString();
            email = binding.updateTeacherEmail.getText().toString();
            post = binding.updateTeacherPost.getText().toString();

            checkValidation();
        });
        binding.deleteBtn.setOnClickListener(view -> {
            pd.setMessage("Deleting...");
            pd.show();
            deleteData();
        });

    }

    private void checkValidation() {

        if (name.isEmpty()) {
            binding.updateTeacherName.setError("Enter Name");
            binding.updateTeacherName.requestFocus();
        } else if (email.isEmpty()) {
            binding.updateTeacherEmail.setError("Enter Email");
            binding.updateTeacherEmail.requestFocus();
        } else if (post.isEmpty()) {
            binding.updateTeacherPost.setError("Enter Post");
            binding.updateTeacherPost.requestFocus();
        } else if (bitmap == null) {
            pd.setMessage("Updating...");
            pd.show();
            updateData(image);
        } else {
            pd.setMessage("Updating...");
            pd.show();
            uploadImage();
        }

    }

    private void updateData(String s) {

        HashMap hp = new HashMap();
        hp.put("name", name);
        hp.put("email", email);
        hp.put("post", post);
        hp.put("image", s);


        reference.child(category).child(uniqueKey).updateChildren(hp)
                .addOnSuccessListener(o -> {
                    pd.dismiss();
                    Toast.makeText(this, "Teacher Data Updated", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(UpdateTeacherActivity.this, UpdateFacultyActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);

                }).addOnFailureListener(e -> {
                    pd.dismiss();
                    Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show();
                });

    }

    private void uploadImage() {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);
        byte[] finalimg = baos.toByteArray();
        final StorageReference filepath;
        filepath = storageReference.child("teachers").child(finalimg + "jpg");
        final UploadTask uploadTask = filepath.putBytes(finalimg);
        uploadTask.addOnCompleteListener(this, task -> {

            if (task.isSuccessful()) {

                uploadTask.addOnSuccessListener(taskSnapshot -> {

                    filepath.getDownloadUrl().addOnSuccessListener(uri -> {

                        downloadUrl = String.valueOf(uri);
                        updateData(downloadUrl);
                    });
                });
            } else {
                    pd.dismiss();
                Toast.makeText(this, task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void deleteData() {
        reference.child(category).child(uniqueKey).removeValue()
                .addOnCompleteListener(task -> {
                    pd.dismiss();
                    Toast.makeText(this, "Teacher Data Deleted", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(UpdateTeacherActivity.this, UpdateFacultyActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }).addOnFailureListener(e -> {
                    pd.dismiss();
                    Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show();
                });
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQ);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ && resultCode == RESULT_OK) {
            Uri uri = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            binding.updateTeacherImg.setImageBitmap(bitmap);
        }

    }

}