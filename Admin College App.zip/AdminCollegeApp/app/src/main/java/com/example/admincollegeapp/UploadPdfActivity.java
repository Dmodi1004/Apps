package com.example.admincollegeapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.admincollegeapp.Notice.UploadNoticeActivity;
import com.example.admincollegeapp.databinding.ActivityUploadPdfBinding;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.util.HashMap;

public class UploadPdfActivity extends AppCompatActivity {

    ActivityUploadPdfBinding binding;

    FirebaseDatabase database;
    DatabaseReference databaseReference;
    FirebaseStorage storage;
    StorageReference storageReference;

    String downloadUrl = "";
    String pdfName, title;

    private ProgressDialog pd;
    private final int REQ = 10;
    private Uri pdfData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUploadPdfBinding.inflate(getLayoutInflater());
        setTheme(R.style.Theme_AdminCollegeApp);
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        pd = new ProgressDialog(this);
        pd.setCancelable(false);

        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();
        databaseReference = database.getReference();
        storageReference = storage.getReference();

        binding.addPdf.setOnClickListener(view -> {
//            Toast.makeText(this, "Working on it.", Toast.LENGTH_SHORT).show();
            openGallery();
        });

        binding.uploadPdfBtn.setOnClickListener(view -> {

            title = binding.pdfTitle.getText().toString();
            if (title.isEmpty()) {
                binding.pdfTitle.setError("Enter the title");
                binding.pdfTitle.requestFocus();
            } else if (pdfData == null) {
                Toast.makeText(this, "Please upload pdf.", Toast.LENGTH_SHORT).show();
            } else {
                uploadPdf();
            }

        });

    }

    private void uploadPdf() {

        pd.setTitle("Uploading Pdf");
        pd.setMessage("Wait a few seconds...");
        pd.show();

        StorageReference reference = storageReference.child("pdf/" + pdfName + "-" + System.currentTimeMillis() + ".pdf");
        reference.putFile(pdfData)
                .addOnSuccessListener(taskSnapshot -> {
                    Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                    while (!uriTask.isComplete()) ;

                    Uri uri = uriTask.getResult();
                    uploadData(String.valueOf(uri));
                }).addOnFailureListener(e -> {
                    pd.dismiss();
                    Toast.makeText(this, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void uploadData(String downloadUrl) {

        String uniqueKey = databaseReference.child("pdf").push().getKey();
        HashMap data = new HashMap();
        data.put("pdfTitle", binding.pdfTitle.getText().toString());
        data.put("pdfUrl", downloadUrl);

        databaseReference.child("pdf").child(uniqueKey).setValue(data)
                .addOnCompleteListener(task -> {
                    pd.dismiss();
                    Toast.makeText(this, "Pdf uploaded successfully", Toast.LENGTH_SHORT).show();
                    binding.pdfTitle.setText("");
                }).addOnFailureListener(e -> {
                    pd.dismiss();
                    Toast.makeText(this, "Failed to upload pdf", Toast.LENGTH_SHORT).show();
                });

    }

    private void openGallery() {

        Intent intent = new Intent();
        intent.setType("application/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select PDF file"), REQ);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ && resultCode == RESULT_OK) {
            pdfData = data.getData();

            if (pdfData.toString().startsWith("content://")) {

                Cursor cursor = null;
                try {
                    cursor = UploadPdfActivity.this.getContentResolver().query(pdfData, null, null, null, null);
                    if (cursor != null && cursor.moveToFirst()) {
                        pdfName = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            } else if (pdfData.toString().startsWith("file://")) {
                pdfName = new File(pdfData.toString()).getName();
            }
            binding.pdfTv.setText(pdfName);
        }

    }
}