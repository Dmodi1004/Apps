package com.example.admincollegeapp.Notice;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.admincollegeapp.Adapters.NoticeAdapter;
import com.example.admincollegeapp.Models.NoticeData;
import com.example.admincollegeapp.R;
import com.example.admincollegeapp.databinding.ActivityDeleteNoticeBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class DeleteNoticeActivity extends AppCompatActivity {

    ActivityDeleteNoticeBinding binding;

    private ArrayList<NoticeData> list;
    private NoticeAdapter adapter;

    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDeleteNoticeBinding.inflate(getLayoutInflater());
        setTheme(R.style.Theme_AdminCollegeApp);
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        reference = FirebaseDatabase.getInstance().getReference().child("notice");

        binding.deleteNoticeRv.setLayoutManager(new LinearLayoutManager(this));
        binding.deleteNoticeRv.setHasFixedSize(true);

        getNotice();

    }

    private void getNotice() {
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list = new ArrayList<>();

                for (DataSnapshot snapshot : dataSnapshot.getChildren() ){
                    NoticeData data = snapshot.getValue(NoticeData.class);
                    list.add(data);
                }
                adapter = new NoticeAdapter(DeleteNoticeActivity.this, list);
                adapter.notifyDataSetChanged();

                binding.progressBar.setVisibility(View.GONE);

                binding.deleteNoticeRv.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                binding.progressBar.setVisibility(View.GONE);
                Toast.makeText(DeleteNoticeActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}