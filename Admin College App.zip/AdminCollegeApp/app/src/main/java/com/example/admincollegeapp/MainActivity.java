package com.example.admincollegeapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.admincollegeapp.Faculty.UpdateFacultyActivity;
import com.example.admincollegeapp.Notice.DeleteNoticeActivity;
import com.example.admincollegeapp.Notice.UploadNoticeActivity;
import com.example.admincollegeapp.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ActivityMainBinding binding;

    /*private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setTheme(R.style.Theme_AdminCollegeApp);
        setContentView(binding.getRoot());


        binding.addNotice.setOnClickListener(this);
        binding.addGallery.setOnClickListener(this);
        binding.addEbook.setOnClickListener(this);
        binding.faculty.setOnClickListener(this);
        binding.deleteNotice.setOnClickListener(this);

        /*sharedPreferences = this.getSharedPreferences("login", MODE_PRIVATE);
        editor = sharedPreferences.edit();

        if (sharedPreferences.getString("isLogin", "false").equals("false")) {
            openLogin();
        }*/

    }
    /*private void openLogin() {
        startActivity(new Intent(MainActivity.this, LoginActivity.class));
        finishAffinity();
    }*/

    @Override
    public void onClick(View view) {

        Intent intent;

        switch (view.getId()) {
            case R.id.addNotice:
                startActivity(new Intent(MainActivity.this, UploadNoticeActivity.class));
                break;

            case R.id.addGallery:
                startActivity(new Intent(MainActivity.this, UploadImageActivity.class));
                break;

            case R.id.addEbook:
                startActivity(new Intent(MainActivity.this, UploadPdfActivity.class));
                break;

            case R.id.faculty:
                startActivity(new Intent(MainActivity.this, UpdateFacultyActivity.class));
                break;

            case R.id.deleteNotice:
                startActivity(new Intent(MainActivity.this, DeleteNoticeActivity.class));
                break;


        }
    }
}