package com.example.collegeapp.Adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.collegeapp.Models.EbookData;
import com.example.collegeapp.PdfViewerActivity;
import com.example.collegeapp.R;

import java.util.ArrayList;
import java.util.List;

public class EbookAdapter extends RecyclerView.Adapter<EbookAdapter.EbookViewHolder> {
    
    private Context context;
    private List<EbookData> list;

    public EbookAdapter(Context context, List<EbookData> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public EbookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        
        View view = LayoutInflater.from(context).inflate(R.layout.ebook_item_layout, parent, false);
        
        return new EbookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EbookViewHolder holder, final int position) {
        
        holder.ebookName.setText(list.get(position).getPdfTitle());
        
        holder.itemView.setOnClickListener(view -> {
            Intent intent = new Intent(context, PdfViewerActivity.class);
            intent.putExtra("pdfUrl", list.get(position).getPdfUrl());
            context.startActivity(intent);

        });
        
        holder.ebookDownload.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(list.get(position).getPdfUrl()));
            context.startActivity(intent);
        });

        holder.ebookShare.setOnClickListener(view -> {
            try {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_SUBJECT, "College App");
                intent.putExtra(Intent.EXTRA_TEXT, "Download : "+list.get(position).getPdfTitle() + "\n" +list.get(position).getPdfUrl() + context.getApplicationContext().getPackageName());
                context.startActivity(Intent.createChooser(intent, "Share With"));
            } catch (Exception e) {
                Toast.makeText(context, "Unable to share this app", Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void Filterdlist(ArrayList<EbookData> filterlist) {
        list = filterlist;
        notifyDataSetChanged();
    }

    public class EbookViewHolder extends RecyclerView.ViewHolder {
        
        private TextView ebookName;
        private ImageView ebookDownload, ebookShare;

        public EbookViewHolder(@NonNull View itemView) {
            super(itemView);
            
            ebookDownload = itemView.findViewById(R.id.ebookDownload);
            ebookName = itemView.findViewById(R.id.ebookName);
            ebookShare = itemView.findViewById(R.id.ebookShare);

        }
    }
    
}
