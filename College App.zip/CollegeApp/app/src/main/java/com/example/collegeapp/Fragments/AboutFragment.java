package com.example.collegeapp.Fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.example.collegeapp.Adapters.BranchAdapter;
import com.example.collegeapp.Models.BranchModel;
import com.example.collegeapp.R;
import com.example.collegeapp.databinding.FragmentAboutBinding;

import java.util.ArrayList;
import java.util.List;

public class AboutFragment extends Fragment {

    private BranchAdapter adapter;
    private List<BranchModel> list;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        FragmentAboutBinding binding = FragmentAboutBinding.inflate(inflater, container, false);

        list = new ArrayList<>();
        list.add(new BranchModel(R.drawable.ic_comp,"Computer Science", "Computer science is the study of computation, automation, and information. Computer science spans theoretical disciplines to practical disciplines."));
        list.add(new BranchModel(R.drawable.ic_mechinacle, "Mechanical Production", "Mechanical engineering is an engineering branch that combines engineering physics and mathematics principles with materials science, to design, analyze, manufacture, and maintain mechanical systems."));

        adapter = new BranchAdapter(getContext(), list);
        binding.viewPager.setAdapter(adapter);

        Glide.with(getContext())
                .load("https://firebasestorage.googleapis.com/v0/b/admin-college-app-7a447.appspot.com/o/college.jpg?alt=media&token=03e4b35a-4f00-4c66-8c23-d35e72194821")
                .into(binding.clgImg);

        binding.map.setOnClickListener(view -> {
            openMap();
        });

        return binding.getRoot();
    }

    private void openMap() {
        Uri uri = Uri.parse("geo:0, 0?q=Sardar Patel University, Mota Bazaar, Vallabh Vidyanagar, Anand, Gujarat");

        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.setPackage("com.google.android.apps.maps");
        startActivity(intent);
    }
}