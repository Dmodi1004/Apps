package com.example.collegeapp.Authentication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.collegeapp.R;
import com.example.collegeapp.databinding.ActivityForgotPasswordBinding;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotPasswordActivity extends AppCompatActivity {

    ActivityForgotPasswordBinding binding;

    String email;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.Theme_CollegeApp);
        binding = ActivityForgotPasswordBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();
        getWindow().setStatusBarColor(getResources().getColor(R.color.rg_bg));

        auth = FirebaseAuth.getInstance();

        binding.forget.setOnClickListener(view -> {
            validateData();
        });

    }

    private void validateData() {
        email = binding.forgEmail.getText().toString();

        if (email.isEmpty()) {
            binding.forgEmail.setError("Enter your email");
        } else {
            forgetPass();
        }
    }

    private void forgetPass() {
        auth.sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(this, "Check your E-mail", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(this, LoginActivity.class));
                        finish();
                    } else {
                        Toast.makeText(this, "Error : "+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}