package com.example.collegeapp.Authentication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.collegeapp.MainActivity;
import com.example.collegeapp.R;
import com.example.collegeapp.databinding.ActivityRegisterBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity {

    ActivityRegisterBinding binding;

    private String name, email, password;

    private FirebaseAuth auth;
    private FirebaseDatabase database;
    private DatabaseReference reference, dbRef;

    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.Theme_CollegeApp);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();
        getWindow().setStatusBarColor(getResources().getColor(R.color.rg_bg));

        dialog = new ProgressDialog(this);
        dialog.setMessage("Creating your account...");
        dialog.setCancelable(false);
        dialog.create();

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        reference = database.getReference();

        binding.register.setOnClickListener(view -> {
            validateData();
        });

        binding.openLog.setOnClickListener(view -> {
            startActivity(new Intent(this, LoginActivity.class));
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (auth.getCurrentUser() != null) {
            openMain();
        }
    }

    private void openMain() {
        startActivity(new Intent(this, MainActivity.class));
        finishAffinity();
    }

    private void validateData() {

        name = binding.registerName.getText().toString();
        email = binding.registerEmail.getText().toString();
        password = binding.registerPassword.getText().toString();

        if (name.isEmpty()) {
            binding.registerName.setError("Enter Your Name");
            binding.registerName.requestFocus();
        } else if (email.isEmpty()) {
            binding.registerEmail.setError("Enter Your E-mail");
            binding.registerEmail.requestFocus();
        } else if (password.isEmpty()) {
            binding.registerPassword.setError("Enter Your Password");
            binding.registerPassword.requestFocus();
        } else {
            createUser();
        }

    }

    private void createUser() {

        dialog.show();

        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        dialog.dismiss();
                        uploadData();
                    } else {
                        dialog.dismiss();
                        Toast.makeText(this, "Error : " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    dialog.dismiss();
                    Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
                });

    }

    private void uploadData() {

        dbRef = reference.child("users");
        String key = dbRef.push().getKey();

        HashMap<String, String> user = new HashMap<>();
        user.put("key", key);
        user.put("name", name);
        user.put("email", email);
        user.put("password", binding.registerPassword.getText().toString());

        dbRef.child(key).setValue(user)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        dialog.dismiss();
                        Toast.makeText(this, "User Created", Toast.LENGTH_SHORT).show();
                        openMain();
                    } else {
                        dialog.dismiss();
                        Toast.makeText(this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(e -> {
                    dialog.dismiss();
                    Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
                });

    }
}