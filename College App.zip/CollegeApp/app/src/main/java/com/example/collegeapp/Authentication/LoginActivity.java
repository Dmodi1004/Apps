package com.example.collegeapp.Authentication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.example.collegeapp.MainActivity;
import com.example.collegeapp.R;
import com.example.collegeapp.databinding.ActivityLoginBinding;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    ActivityLoginBinding binding;

    String email, password;
    FirebaseAuth auth;

    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.Theme_CollegeApp);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();
        getWindow().setStatusBarColor(getResources().getColor(R.color.rg_bg));

        auth = FirebaseAuth.getInstance();

        dialog = new ProgressDialog(this);
        dialog.setCancelable(false);
        dialog.setMessage("LogIn...");
        dialog.create();

        binding.openReg.setOnClickListener(view -> {
            startActivity(new Intent(this, RegisterActivity.class));
        });

        binding.login.setOnClickListener(view -> {
            validateData();
        });

        binding.openForgPass.setOnClickListener(view -> {
            startActivity(new Intent(this, ForgotPasswordActivity.class));
        });

    }

    private void validateData() {
        email = binding.logEmail.getText().toString();
        password = binding.logPassword.getText().toString();

        if (email.isEmpty()){
            binding.logEmail.setError("Enter your email");
            binding.logEmail.requestFocus();
        } else if (password.isEmpty()){
            binding.logPassword.setError("Enter your password");
            binding.logPassword.requestFocus();
        } else {
            loginUser();
        }

    }

    private void loginUser() {
        dialog.show();
        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()){
                        dialog.dismiss();
                        openMain();
                    } else {
                        dialog.dismiss();
                        Toast.makeText(this, "Error: "+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(e -> {
                    dialog.dismiss();
                    Toast.makeText(this, "Error : "+e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void openMain() {
        startActivity(new Intent(this, MainActivity.class));
        finishAffinity();
    }
}