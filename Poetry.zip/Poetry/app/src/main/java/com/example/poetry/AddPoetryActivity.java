package com.example.poetry;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.poetry.Api.ApiClient;
import com.example.poetry.Api.ApiInterface;
import com.example.poetry.Response.DeleteResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class AddPoetryActivity extends AppCompatActivity {

    Toolbar toolbar;
    EditText poetryData, poetName;
    AppCompatButton submitBtn;
    ApiInterface apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_poetry);

        intialization();
        setuptoolbar();

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String poetryDataString = poetryData.getText().toString();
                String poetNameString = poetName.getText().toString();

                if (poetryDataString.equals("")) {
                    poetryData.setError("Enter Your Poetry");
                } else {
                    if (poetNameString.equals("")) {
                        poetName.setError("Enter Your Name");
                    } else {
                        callapi(poetryDataString, poetNameString);
                    }
                }
            }
        });

    }

    private void intialization() {

        toolbar = findViewById(R.id.add_poetry_toolbar);
        poetName = findViewById(R.id.add_poet_name_et);
        poetryData = findViewById(R.id.add_poetry_data_et);
        submitBtn = findViewById(R.id.submit_data_btn);

        Retrofit retrofit = ApiClient.getclient();
        apiInterface = retrofit.create(ApiInterface.class);

    }

    private void setuptoolbar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void callapi(String poetryData, String poetName) {

        apiInterface.addpoetry(poetryData, poetName).enqueue(new Callback<DeleteResponse>() {
            @Override
            public void onResponse(Call<DeleteResponse> call, Response<DeleteResponse> response) {
                try {
                    if (response.body().getStatus().equals("1")) {
                        Toast.makeText(AddPoetryActivity.this, "Added Successfully", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(AddPoetryActivity.this, "Not Added Successfully", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Log.e("ecp", e.getLocalizedMessage());

                }
            }

            @Override
            public void onFailure(Call<DeleteResponse> call, Throwable t) {
                Log.e("Failure", t.getLocalizedMessage());
            }
        });
    }

}