package com.example.poetry;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.poetry.Api.ApiClient;
import com.example.poetry.Api.ApiInterface;
import com.example.poetry.Response.DeleteResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class UpdatePoetryActivity extends AppCompatActivity {

    Toolbar toolbar;
    EditText poetryData;
    AppCompatButton submitBtn;
    int poetryId;
    String poetryDataString;
    ApiInterface apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_poetry);

        initialization();
        setUpToolbar();

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String p_data = poetryData.getText().toString();
                if (p_data.equals(""))
                {
                    poetryData.setError("Field is empty");
                }
                else {
                    callapi(p_data, poetryId+"");
                }

            }
        });

    }

    protected void initialization(){
        toolbar = findViewById(R.id.update_poetry_toolbar);
        poetryData = findViewById(R.id.update_poetry_data_et);
        submitBtn = findViewById(R.id.update_submit_data_btn);

        poetryId = getIntent().getIntExtra("p_id", 0);
        poetryDataString = getIntent().getStringExtra("p_data");
        poetryData.setText(poetryDataString);

        Retrofit retrofit = ApiClient.getclient();
        apiInterface = retrofit.create(ApiInterface.class);

    }

    private void setUpToolbar(){
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void callapi(String pData, String pId){


        apiInterface.updatepoetry(pData, pId).enqueue(new Callback<DeleteResponse>() {
            @Override
            public void onResponse(Call<DeleteResponse> call, Response<DeleteResponse> response) {
                try {
                    if (response.body().getStatus().equals("1"))
                    {
                        Toast.makeText(UpdatePoetryActivity.this, "Data updated", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(UpdatePoetryActivity.this, "Data not updated", Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception e){
                    Log.e("updatexp", e.getLocalizedMessage());
                }
            }

            @Override
            public void onFailure(Call<DeleteResponse> call, Throwable t) {
                Log.e("Update Failed", t.getLocalizedMessage());
            }
        });
    }

}