package com.example.mychat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.mychat.Adapters.MessageAdapter;
import com.example.mychat.Models.MessageModel;
import com.example.mychat.Models.UserModel;
import com.example.mychat.databinding.ActivityChatBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.UUID;

public class ChatActivity extends AppCompatActivity {

    ActivityChatBinding binding;
    String receiverId;
    DatabaseReference referenceSender, referenceReceiver;
    FirebaseAuth auth;
    FirebaseDatabase database;
    String senderRoom, receiverRoom;
    MessageAdapter messageAdapter;
    ArrayList<MessageModel> messageModel = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        String userName = getIntent().getStringExtra("userName");
        String profile = getIntent().getStringExtra("profile");

        binding.userName.setText(userName);

        Picasso.get()
                .load(profile)
                .placeholder(R.drawable.avatar)
                .into(binding.profile);

        binding.back.setOnClickListener(view -> {
            startActivity(new Intent(ChatActivity.this, MainActivity.class));
            finishAffinity();
        });

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        receiverId = getIntent().getStringExtra("id");

        senderRoom = auth.getUid() + receiverId;
        receiverRoom = receiverId + auth.getUid();

        messageAdapter = new MessageAdapter(messageModel, this);
        binding.recycler.setAdapter(messageAdapter);
        binding.recycler.setLayoutManager(new LinearLayoutManager(this));

        referenceSender = database.getReference("chats").child(senderRoom);
        referenceReceiver = database.getReference("chats").child(receiverRoom);

        referenceSender.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                messageAdapter.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    MessageModel messageModel = dataSnapshot.getValue(MessageModel.class);
                    messageAdapter.add(messageModel);
                }
                messageAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        binding.send.setOnClickListener(view -> {

            String message = binding.messageEdt.getText().toString();
            if (message.isEmpty()) {
                binding.send.setVisibility(View.GONE);
                Toast.makeText(this, "Type Something", Toast.LENGTH_SHORT).show();
            } else {
                binding.send.setVisibility(View.VISIBLE);
                sendMessage(message);
            }
        });

    }

    private void sendMessage(String message) {

        binding.messageEdt.setText(null);

        String msgId = UUID.randomUUID().toString();
        MessageModel messageModel = new MessageModel(msgId, auth.getUid(), message);

        messageAdapter.add(messageModel);

        referenceSender.child(msgId)
                .setValue(messageModel);
        referenceReceiver.child(msgId)
                .setValue(messageModel);

    }
}