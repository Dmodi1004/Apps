package com.example.mychat;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mychat.Models.UserModel;
import com.example.mychat.databinding.ActivityUserProfileBinding;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

public class UserProfileActivity extends AppCompatActivity {

    ActivityUserProfileBinding binding;
    FirebaseAuth auth;
    FirebaseDatabase database;
    FirebaseStorage storage;
    AlertDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUserProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();

        dialog = new AlertDialog.Builder(this)
                .setTitle("LOGOUT")
                .setMessage("Are you sure you want to Logout ?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        auth.signOut();
                        startActivity(new Intent(UserProfileActivity.this, AuthenticationActivity.class));
                        finishAffinity();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialog.dismiss();
                    }
                })
                .create();

        binding.back.setOnClickListener(view -> {
            startActivity(new Intent(UserProfileActivity.this, MainActivity.class));
            finishAffinity();
        });

        binding.logout.setOnClickListener(view -> {
            dialog.show();
        });

        binding.profile.setOnClickListener(view -> {
            ImagePicker.Companion.with(UserProfileActivity.this)
                    .crop()                    //Crop image(Optional), Check Customization for more option
                    .maxResultSize(1080, 1080)    //Final image resolution will be less than 1080 x 1080(Optional)
                    .start();
        });

        database.getReference().child("users")
                .child(auth.getUid())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        if (snapshot.exists()) {
                            UserModel userModel = snapshot.getValue(UserModel.class);

                            Picasso.get()
                                    .load(userModel.getProfile())
                                    .placeholder(R.drawable.avatar)
                                    .into(binding.profile);

                            binding.name.setText(userModel.getUserName());
                            binding.email.setText(userModel.getUserEmail());

                        } else {
                            Toast.makeText(UserProfileActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(UserProfileActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        binding.name.setOnClickListener(view -> {

            binding.saveName.setTextColor(getResources().getColor(R.color.white));

        });

        binding.saveName.setOnClickListener(view -> {

            String name = binding.name.getText().toString();

            binding.saveName.setTextColor(getResources().getColor(R.color.transparent));

            if (name.isEmpty()) {
                Toast.makeText(this, "Enter the name", Toast.LENGTH_SHORT).show();
            } else {

                Toast.makeText(this, "Name Update", Toast.LENGTH_SHORT).show();

                HashMap<String, Object> obj = new HashMap<>();
                obj.put("userName", name);

                database.getReference().child("users").child(FirebaseAuth.getInstance().getUid())
                        .updateChildren(obj);

            }
        });

        binding.email.setOnClickListener(view -> {
            binding.saveEmail.setTextColor(getResources().getColor(R.color.white));
        });

        binding.saveEmail.setOnClickListener(view -> {

            String email = binding.email.getText().toString();

            binding.saveEmail.setTextColor(getResources().getColor(R.color.transparent));

            if (email.isEmpty()) {
                Toast.makeText(this, "Enter the email", Toast.LENGTH_SHORT).show();
            } else {

                Toast.makeText(this, "Email Update", Toast.LENGTH_SHORT).show();

                HashMap<String, Object> obj = new HashMap<>();
                obj.put("userEmail", email);

                database.getReference().child("users").child(FirebaseAuth.getInstance().getUid())
                        .updateChildren(obj);
            }

        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (data.getData() != null) {
            Uri uri = data.getData();
            binding.profile.setImageURI(uri);

            final StorageReference reference = storage.getReference().child("profile")
                    .child(FirebaseAuth.getInstance().getUid());
            reference.putFile(uri).addOnSuccessListener(taskSnapshot -> {
                Toast.makeText(this, "Photo Uploaded", Toast.LENGTH_SHORT).show();

                reference.getDownloadUrl().addOnSuccessListener(uri1 -> {
                    database.getReference().child("users")
                            .child(auth.getUid()).child("profile")
                            .setValue(uri1.toString());
                });

            });

        }

    }
}