package com.example.mychat;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mychat.Models.UserModel;
import com.example.mychat.databinding.ActivityAuthenticationBinding;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class AuthenticationActivity extends AppCompatActivity {

    ActivityAuthenticationBinding binding;
    String name, email, password, profile;
    FirebaseAuth auth;
    FirebaseStorage storage;
    FirebaseDatabase database;
    DatabaseReference databaseReference;
    AlertDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAuthenticationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        dialog = new AlertDialog.Builder(this)
                .setView(R.layout.dialog)
                .setCancelable(false)
                .create();

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();

        databaseReference = database.getReference("users");

        binding.login.setOnClickListener(view -> {


            email = binding.email.getText().toString();
            password = binding.pasword.getText().toString();

            if (email.isEmpty()) {
                binding.email.setError("Enter your email");

            } else if (password.isEmpty()) {
                binding.pasword.setError("Enter your password");

            } else {
                login();

            }

        });

        binding.signup.setOnClickListener(view -> {


            name = binding.name.getText().toString();
            email = binding.email.getText().toString();
            password = binding.pasword.getText().toString();
//            profile = binding.profile.toString();

            if (name.isEmpty()) {
                binding.name.setError("Enter your name");

            } else if (email.isEmpty()) {
                binding.email.setError("Enter your email");

            } else if (password.isEmpty()) {
                binding.pasword.setError("Enter your password");

            } else {
                singUp();

            }

        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (auth.getCurrentUser() != null) {
            startActivity(new Intent(AuthenticationActivity.this, MainActivity.class));
            finishAffinity();
        }
    }

    private void login() {
        dialog.show();
        auth.signInWithEmailAndPassword(email.trim(), password)
                .addOnSuccessListener(authResult -> {
                    dialog.dismiss();
                    startActivity(new Intent(AuthenticationActivity.this, MainActivity.class));
                    finishAffinity();
                });
    }

    private void singUp() {
        dialog.show();
        auth.createUserWithEmailAndPassword(email.trim(), password)
                .addOnSuccessListener(authResult -> {

                    UserProfileChangeRequest userProfileChangeRequest = new UserProfileChangeRequest.Builder().setDisplayName(name).build();

                    FirebaseUser firebaseUser = auth.getCurrentUser();
                    firebaseUser.updateProfile(userProfileChangeRequest);

                    UserModel userModel = new UserModel(auth.getUid(), name, email, password, profile);

                    databaseReference.child(auth.getUid()).setValue(userModel);

                    dialog.dismiss();

                    startActivity(new Intent(AuthenticationActivity.this, MainActivity.class));
                    finishAffinity();
                });

    }

}