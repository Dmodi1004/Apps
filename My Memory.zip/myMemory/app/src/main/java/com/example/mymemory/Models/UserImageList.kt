package com.example.mymemory.Models

import com.google.firebase.database.PropertyName

data class UserImageList(
    @PropertyName("images") val images: List<String>? = null,

    )
