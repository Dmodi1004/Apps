package com.example.mymemory

import android.animation.ArgbEvaluator
import android.app.Activity
import android.content.ContentValues.TAG
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.example.mymemory.Adapters.MemoryBoardAdapter
import com.example.mymemory.Models.BoardSize
import com.example.mymemory.Models.MemoryGame
import com.example.mymemory.Models.UserImageList
import com.example.mymemory.Utils.EXTRA_BOARD_SIZE
import com.example.mymemory.Utils.EXTRA_GAME_NAME
import com.github.jinatonic.confetti.CommonConfetti
import com.google.android.gms.tasks.OnFailureListener
import com.google.android.gms.tasks.OnSuccessListener
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.dialog_board_size.view.*
import kotlinx.android.synthetic.main.dialog_download_board.*


class MainActivity : AppCompatActivity() {

    private lateinit var memoryGame: MemoryGame
    private lateinit var adapter: MemoryBoardAdapter
    private var boardSize: BoardSize = BoardSize.EASY

    private val CREATE_REQUEST_CODE = 10

    private val db = Firebase.firestore
    private val storage = Firebase.storage
    private var gameName: String? = null
    private var customGameImages: List<String>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupBoard()

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.miRefresh -> {
                //Setup the game again
                if (memoryGame.getNumMoves() >= 0 && !memoryGame.haveWonGame()) {
                    showAlertDialog("Quit your current game ?", null, View.OnClickListener {
                        setupBoard()
                    })
                } else {
                    setupBoard()
                }
                return true
            }
            R.id.miNewSize -> {
                showNewSizeDialog()
                return true
            }
            R.id.miCustom -> {
                showCreationDialog()
                return true
            }
            R.id.mi_download -> {
                showDownloadDialog()
                return true
            }
            R.id.mi_delete -> {
                showDeleteDialog()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == CREATE_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val customGameName: String? = data?.getStringExtra(EXTRA_GAME_NAME)
            if (customGameName == null) {
                Log.e(TAG, "Got null custom game from Create Activity")
                return
            }
            downloadGame(customGameName)
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun showDeleteDialog() {
        val boardDeleteView =
            LayoutInflater.from(this).inflate(R.layout.dialog_download_board, null)
        showAlertDialog("You want to Delete ?", boardDeleteView, View.OnClickListener {
            //Grab the text of the game name that user wants to download
            val etDeleteGame: EditText = boardDeleteView.findViewById<EditText>(R.id.etDownloadGame)
            val gameToDelete: String = etDeleteGame.text.toString().trim()
            deleteGame(gameToDelete)
        })
    }

    private fun deleteGame(customGameName: String) {
        db.collection("games").document(customGameName).get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful && customGameName.isNotEmpty()) {
                    db.collection("games").document(customGameName)
                        .delete()
                        .addOnSuccessListener {
                            Snackbar.make(clRoot, "Successfully Deleted", Snackbar.LENGTH_LONG)
                                .show()
                        }.addOnFailureListener { e ->
                            Log.e(TAG, "error: $e.localizedMessage")
                        }
                } else {
                    Snackbar.make(clRoot, "Something went wrong", Snackbar.LENGTH_LONG).show()
                }
            }

        /*val storageRef = storage.reference
        val ref = storageRef.child("images/ $gameName")
        ref.delete().addOnSuccessListener {
            Log.i(TAG, "Success")
        }.addOnFailureListener {
            Snackbar.make(clRoot, "Something went wrong", Snackbar.LENGTH_LONG).show()
        }*/

    }

    private fun showDownloadDialog() {
        val boardDownloadView =
            LayoutInflater.from(this).inflate(R.layout.dialog_download_board, null)
        showAlertDialog("Fetch memory game", boardDownloadView, View.OnClickListener {
            //Grab the text of the game name that user wants to download
            val etDownloadGame: EditText =
                boardDownloadView.findViewById<EditText>(R.id.etDownloadGame)
            val gameToDownload: String = etDownloadGame.text.toString().trim()
            downloadGame(gameToDownload)
        })
    }

    private fun downloadGame(customGameName: String) {
        db.collection("games").document(customGameName).get().addOnSuccessListener { document ->
            val userImageList: UserImageList? = document.toObject(UserImageList::class.java)
            if (userImageList?.images == null) {
                Log.e(TAG, "Invalid custom game data from Firestore")
                Snackbar.make(
                    clRoot,
                    "Sorry, we couldn't find any such game, '$gameName'",
                    Snackbar.LENGTH_LONG
                ).show()
                return@addOnSuccessListener
            }
            val numCards = userImageList.images.size * 2
            boardSize = BoardSize.getByValue(numCards)
            customGameImages = userImageList.images
            for (imageUrl in userImageList.images) {
                Picasso.get().load(imageUrl).fetch()
            }
            Snackbar.make(clRoot, "You are now playing '$customGameName'", Snackbar.LENGTH_LONG)
                .show()
            gameName = customGameName
            setupBoard()
        }.addOnFailureListener { exception ->
            Log.e(TAG, "Exception when retrieving game", exception)
        }
    }

    private fun showCreationDialog() {
        val boardSizeView = LayoutInflater.from(this).inflate(R.layout.dialog_board_size, null)
        val radioGroupSize = boardSizeView.radioGroup

        showAlertDialog("Create your own memory board", boardSizeView, View.OnClickListener {
            //Set a new value for the board size
            val desiredBoardSize = when (radioGroupSize.checkedRadioButtonId) {
                R.id.rbEasy -> BoardSize.EASY
                R.id.rbMedium -> BoardSize.MEDIUM
                else -> {
                    BoardSize.HARD
                }
            }
            //Navigate to a new activity
            val intent = Intent(this, CreateActivity::class.java)
            intent.putExtra(EXTRA_BOARD_SIZE, desiredBoardSize)
            startActivityForResult(intent, CREATE_REQUEST_CODE)
        })

    }

    private fun showNewSizeDialog() {

        val boardSizeView = LayoutInflater.from(this).inflate(R.layout.dialog_board_size, null)
        val radioGroupSize = boardSizeView.radioGroup

        when (boardSize) {
            BoardSize.EASY -> radioGroupSize.check(R.id.rbEasy)
            BoardSize.MEDIUM -> radioGroupSize.check(R.id.rbMedium)
            BoardSize.HARD -> radioGroupSize.check(R.id.rbHard)
        }

        showAlertDialog("Choose new size", boardSizeView, View.OnClickListener {
            //Set a new value for the board size
            boardSize = when (radioGroupSize.checkedRadioButtonId) {
                R.id.rbEasy -> BoardSize.EASY
                R.id.rbMedium -> BoardSize.MEDIUM
                else -> {
                    BoardSize.HARD
                }
            }
            gameName = null
            customGameImages = null

            setupBoard()
        })
    }

    private fun showAlertDialog(
        title: String,
        view: View?,
        positiveClickListener: View.OnClickListener,
    ) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(view)
            .setNegativeButton("No", null)
            .setPositiveButton("Confirm") { _, _ ->
                positiveClickListener.onClick(null)
            }.show()
    }

    private fun setupBoard() {

        supportActionBar?.title = gameName ?: getString(R.string.app_name)

        when (boardSize) {
            BoardSize.EASY -> {
                tvMoves.text = "Easy: 4 x 2"
                tvPairs.text = "Pairs: 0 / 4"
            }
            BoardSize.MEDIUM -> {
                tvMoves.text = "Medium: 6 x 3"
                tvPairs.text = "Pairs: 0 / 9"
            }
            BoardSize.HARD -> {
                tvMoves.text = "Hard: 7 x 4"
                tvPairs.text = "Pairs: 0 / 12"
            }
        }

        tvPairs.setTextColor(ContextCompat.getColor(this, R.color.color_progress_none))

        memoryGame = MemoryGame(boardSize, customGameImages)

        adapter = MemoryBoardAdapter(this,
            boardSize,
            memoryGame.cards,
            object : MemoryBoardAdapter.CardClickListener {
                override fun onCardClicked(position: Int) {
                    updateGameWithFlip(position)
                }

            })
        rvBoard.adapter = adapter
        rvBoard.setHasFixedSize(true)
        rvBoard.layoutManager = GridLayoutManager(this, boardSize.getWidth())
    }

    private fun updateGameWithFlip(position: Int) {

        //Error Checking
        if (memoryGame.haveWonGame()) {
            //Alert the use of an invalid move
            Snackbar.make(clRoot, "You already won!!", Snackbar.LENGTH_LONG).show()
            return
        }
        if (memoryGame.isCardFaceUp(position)) {
            //Alert the user of an invalid move
            Snackbar.make(clRoot, "Invalid move!!", Snackbar.LENGTH_SHORT).show()
            return
        }

        //Actually flip over the card
        if (memoryGame.flipCard(position)) {
            Log.i("MainActivity", "Found a match! Num pairs found: ${memoryGame.numPairsFound}")
            var color = ArgbEvaluator().evaluate(
                memoryGame.numPairsFound.toFloat() / boardSize.getNumPairs(),
                ContextCompat.getColor(this, R.color.color_progress_none),
                ContextCompat.getColor(this, R.color.color_progress_full)
            ) as Int
            tvPairs.setTextColor(color)
            tvPairs.text = "Pairs: ${memoryGame.numPairsFound} / ${boardSize.getNumPairs()}"
            if (memoryGame.haveWonGame()) {
                Snackbar.make(clRoot, "You won!! Congratulations 🎉", Snackbar.LENGTH_LONG).show()
                CommonConfetti.rainingConfetti(
                    clRoot,
                    intArrayOf(Color.YELLOW, Color.GREEN, Color.MAGENTA)
                ).oneShot()
            }
        }
        tvMoves.text = "Moves: ${memoryGame.getNumMoves()}"
        adapter.notifyDataSetChanged()

    }
}